<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('phones', function (Blueprint $table) {
            // Make screen_id and camera_id nullable
            $table->unsignedBigInteger('screen_id')->nullable()->change();
            $table->unsignedBigInteger('camera_id')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('phones', function (Blueprint $table) {
            // Make screen_id and camera_id required again
            $table->unsignedBigInteger('screen_id')->nullable(false)->change();
            $table->unsignedBigInteger('camera_id')->nullable(false)->change();
        });
    }
};
